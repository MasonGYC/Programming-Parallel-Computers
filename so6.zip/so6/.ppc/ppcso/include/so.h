#pragma once

typedef unsigned long long data_t;

void psort(int n, data_t *data);
